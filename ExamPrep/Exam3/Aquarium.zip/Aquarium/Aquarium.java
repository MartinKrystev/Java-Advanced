package Aquarium;

import java.util.ArrayList;
import java.util.List;

public class Aquarium {
    private String name;
    private int capacity;
    private int size;
    private List<Fish> fishInPool;

    public Aquarium(String name, int capacity, int size) {
        this.name = name;
        this.capacity = capacity;
        this.size = size;
        this.fishInPool = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getSize() {
        return size;
    }

    public int getFishInPool() {
        return fishInPool.size();
    }

    public void add(Fish fish) {
        String currName = fish.getName();
        if (this.fishInPool.size() < this.capacity) {
            boolean isInside = false;
            for (Fish f : fishInPool) {
                if (f.getName().equals(currName)) {
                    isInside = true;
                    break;
                }
            }
            if (!isInside) {
                fishInPool.add(fish);
            }
        }
    }

    public boolean remove(String name) {
        for (Fish f : fishInPool) {
            if (f.getName().equals(name)) {
                fishInPool.remove(f);
                return true;
            }
        }
        return false;
    }

    public Fish findFish(String name) {
        for (Fish f : fishInPool) {
            String currFish = f.getName();
            if (currFish.equals(name)) {
                return f;
            }
        }
        return null;
    }

    public String report() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Aquarium: %s ^ Size: %d", this.name, this.size));
        sb.append("\n");
        for (Fish f : fishInPool) {
            sb.append(f).append("\n");
        }

        return sb.toString();
    }

}
